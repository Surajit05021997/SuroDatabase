package com.capg.service;

import java.util.List;

import com.capg.beans.Employee;

public interface EmployeeService {

	public Employee getEmployeeById(int eid);
	public List<Employee> getAllEmployee();
	public void deleteEmployee(int eid);
	public Employee addEmployee( Employee emp);
	public Employee updateEmployee(Employee emp);
	public List<Employee> getEmployeeByName(String ename);
	public List<Employee> getEmployeeByRange();
	
}
