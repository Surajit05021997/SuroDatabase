package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.beans.Employee;
import com.capg.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService service;
	
	//Get Employee by Id
	@GetMapping(value = "/employee/{eid}")
	public Employee getEmployeeById(@PathVariable int eid) {
		Employee employee = service.getEmployeeById(eid);
		return employee; //Use return employee.toString(); to get output in text format 
	}
	
	//Get Employee by Name
	@GetMapping(value = "/employeeByName/{ename}")
	public List<Employee> getEmployeeByName(@PathVariable String ename) {
		List<Employee> employee = service.getEmployeeByName(ename);
		return employee;  
	}
	
	//Get Employee by Salary range
	@GetMapping(value = "/employeeByRange")
	public List<Employee> getEmployeeByRange() {
		return service.getEmployeeByRange();
	}
	
	//Get All Employee
	@GetMapping(value = "/allEmployee", produces = {"application/xml"}) //to get data in xml format
	public List<Employee> getAllEmployee() {
		return service.getAllEmployee();
	}
	
	//Delete Employee by Id
	@DeleteMapping(value = "/employee/{eid}")
	public void deleteEmployee(@PathVariable int eid) {
		service.deleteEmployee(eid);
	}
	
	//Insert Employee
	@PostMapping(value = "/employee", consumes= {"application/json"})  //In Post we have to use consumes to get data in json format and @RequestBody must be used bcz data is send through request body in post method.
	public Employee addEmployee(@RequestBody Employee emp) {
		return service.addEmployee(emp);
	}
	
	//Update Employee
	@PutMapping(value = "/employee", consumes= {"application/json"})
	public Employee updateEmployee(@RequestBody Employee emp) {
		return service.updateEmployee(emp);
	}
	
}
